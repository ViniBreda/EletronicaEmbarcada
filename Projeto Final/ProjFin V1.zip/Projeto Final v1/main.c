#include <msp430g2553.h>

//Definition of the notes' frequecies in Hertz.
#define c 261
#define d 294
#define e 329
#define f 349
#define g 391
#define gS 415
#define a 440
#define aS 455
#define b 466
#define cH 523
#define cSH 554
#define dH 587
#define dSH 622
#define eH 659
#define fH 698
#define fSH 740
#define gH 784
#define gSH 830
#define aH 880

//Definition of the physical components

#define BUTTON BIT3
#define SOM1 BIT0
#define SOM2 BIT2

int tic = 0; // timer interrupt counter
unsigned int duration = 0;

//This function generates the square wave that makes the piezo speaker sound at a determinated frequency.
void beep(unsigned int nota, unsigned int duration)
{
// =========== Setup da Sa�da PWM =================
    int quartoNota = nota/4;
    int meiaNota = nota/2;
    TA1CCR0 = nota;
    TA1CCR1 = quartoNota;
    TA1CCTL0 = OUTMOD_7;
    TA1CTL = MC_1 | ID_2 | TASSEL_2 | TACLR;
// =========== Inicializando Interrupt de Tempo ===========
    TA0CCR0 = 999;
// ========== LIGA SOM ===========
    P2SEL |= SOM1 + SOM2;

}


int main (void)
{
    WDTCTL = WDTPW + WDTHOLD; //Disable Watchdog Timer
    P1DIR = 0;
    P1OUT = 0;
    P2DIR |= SOM1 + SOM2;
// =========== Setup Interrupt de Bot�o ===========
    P1REN |= BUTTON;
    P1OUT |= BUTTON;
    P1IE |= BUTTON; // P1.3 interrupt enabled
    P1IES |= BUTTON;  //low to high transition
    P1IFG &= ~BUTTON; // P1.3 IFG cleared
// =========== Setup Interrupt de Tempo ===========
    TA0CCR0 = 0;
    TA0CCTL0 = CCIE;
    TA0CTL = MC_1 | TASSEL_2 | ID_0 | TACLR;
//  TA0CCR0 = 12500;
    __bis_SR_register(GIE);
}


// =========== Interrupt de Bot�o ===========
#pragma vector = PORT1_VECTOR
__interrupt void Button_ISR(void)
{
    duration = 10000;
    beep(a, duration);
    P1IFG &= ~BUTTON; // P1.3 IFG cleared
}

// =========== Interrupt de Tempo ===========
#pragma vector = TIMER0_A0_VECTOR
__interrupt void Timer0_ISR(void)
{
    if(tic >= duration)
    {
        P2SEL &= ~(SOM1 + SOM2);
        TA0CCR0 = 0;
        tic = -1;
    }
    tic++;
}

