// main.c
#include "msp430g2553.h"

//chamada das fun��es globais em assembly
void set_tick(unsigned);
unsigned get_tick(void);
void synth_init();
void set_note(int, unsigned);

#define STATECHANGER BIT2
#define NOTE1 BIT4
#define NOTE2 BIT5
#define NOTE3 BIT0
#define NOTE4 BIT0

//vari�veis
int loop[16] = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};    //guarda as notas do loop
//int loop[16] = {0x5A,0x5A,0x5A,0x5A,0x5A,0x5A,0x5A,0x5A,0x5A,0x5A,0x5A,0x5A,0x5A,0x5A,0x5A,0x5A,};    //guarda as notas do loop
int state = 0;

/*Fun��o tone
 * Entrada: nota antiga
 * Sa�da: nota nova
 * A fun��o detecta qual bot�o foi apertado, caso seja em modo de input, uma nova nota ser� definida
 * caso contr�rio, a nota da entrada ser� retornada (mantida)
 */
int looptone(old)
{
    int new;
    if((P1IN & NOTE1) == 0)
    {
        new = 0x6B;
    }
    else if((P1IN & NOTE2) == 0)
    {
        new = 0x69;
    }
    else if((P1IN & NOTE3) == 0)
    {
        new = 0x67;
    }
    else if((P2IN & NOTE4) == 0)
    {
        new = 0x65;
    }
    else
    {
        new = old;
    }
    return new;
}

void singletone()
{
   if((P1IN & NOTE1) == 0)
   {
       set_note(0x6B, 0);
       set_tick(5000);
       while(get_tick());
   }
   else if((P1IN & NOTE2) == 0)
  {
      set_note(0x69, 0);
      set_tick(5000);
      while(get_tick());
  }
  else if((P1IN & NOTE3) == 0)
  {
      set_note(0x67, 0);
      set_tick(5000);
      while(get_tick());
  }
  else if((P2IN & NOTE4) == 0)
  {
      set_note(0x65, 0);
      set_tick(5000);
      while(get_tick());
  }
  else
  {
      set_note(-1, 0);
      set_tick(1000);
      while(get_tick());
  }
}

void increaseState()
{
    if((P1IN & STATECHANGER) == 0)
    {
       state = state + 1;
    }
}

void main(void)
{

    WDTCTL = WDTPW + WDTHOLD;

    BCSCTL1 = XT2OFF + 15;
    P1DIR = 0xF2;       // I/O assignment
    P1REN = 0x0D;       // Pull up resistor for switch and Rxd
    P1OUT = 0x0F;       // Pull up, serial idle high
    P1SEL = 0x50;       // Enable Timer A output, SMCLK output
    P1DIR &= ~(NOTE1 + NOTE2 + NOTE3);
    P1DIR &= ~STATECHANGER;
    P2DIR &= ~NOTE4;
    P2REN = NOTE4;
    P2OUT = NOTE4;       // Pull up, serial idle high
    synth_init();
    for(;;)
    {
       unsigned int i = 0;

       switch(state)
       {
       case 0:
           singletone();
           increaseState();
       break;
       case 1:
           for(i = 0; i < 15; i++) //4 segundos
           {
               loop[i] = looptone(loop[i]);
               set_note(loop[i], 0);
               set_tick(5000);
               while(get_tick());
               set_note(-1, 0);
               set_tick(5000);
               while(get_tick());
               increaseState();
           }
           increaseState();
       break;
       default:
           state = 0;
       }
    }
}


