#include <msp430g2553.h>

#define     GNLED   BIT0
#define     RDLED   BIT6
#define     TEMPO   1       // 10s = 0; 1 min = 1; 1h = 2; 1 dia = 3;

const int time = TEMPO;
int count = 0;

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;                                               // stop watchdog timer
    P1OUT = 0;                                                              // nada ligado
    P2OUT = 0;
    P1OUT |= GNLED;                                                         // somente o led verde ligado
    P1DIR |= GNLED|RDLED;                                                   // seta todos os outros pinos como input menos os dos LEDs, que s�o setados como output
    TA0CCR0 = 62499;                                                        // divide o clock para um per�odo de 0.5s
    TA0CCTL0 = CCIE;
    TA0CTL = MC_1 | ID_3 | TASSEL_2 | TACLR;                                // conta at� ccr0 e divide o SMCLK por 8
    while(1)
    {
        __bis_SR_register(GIE | LPM0_bits);
    }
}

#pragma vector = TIMER0_A0_VECTOR
__interrupt void Timer0_A0 (void)
{
    LPM0_EXIT;
    if(TEMPO == 0)
    {
        if(count == 20) // para 10s
        {
            P1OUT ^= GNLED|RDLED; //toggle nos leds
            count = 0; // reseta o count
        }
        else
        {
            count++;
        }
    }
    else if(TEMPO == 1)
    {
        if(count == 120) // para 1min
        {
            P1OUT ^= GNLED|RDLED; //toggle nos leds
            count = 0; // reseta o count
        }
        else
        {
            count++;
        }
    }
    else if(TEMPO == 2)
    {
        if(count == 7200) // para 1h
        {
            P1OUT ^= GNLED|RDLED; //toggle nos leds
            count = 0; // reseta o count
        }
        else
        {
            count++;
        }
    }
    else if(TEMPO == 3)
    {
        if(count == 172800) // para 1dia
        {
            P1OUT ^= GNLED|RDLED; //toggle nos leds
            count = 0; // reseta o count
        }
        else
        {
            count++;
        }
    }
}
