#include <msp430g2553.h>

#define BUTTON BIT3 // define do bot�o
#define MSB   BIT6 // define do led vermelho
#define LSB   BIT0 // define do led verde

int ic = 0;

int main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer
	P1DIR |= MSB + LSB; // MSB e LSB s�o sa�das
    P1OUT &= ~MSB;
    P1OUT &= ~LSB;
    P1IE |= BUTTON; // P1.3 interrupt enabled
    P1IES |= BUTTON;  //low to high transition
    P1IFG &= ~BUTTON; // P1.3 IFG cleared
    __bis_SR_register(GIE | LPM0_bits);
}

#pragma vector = PORT1_VECTOR
__interrupt void BUTTON_ISR(void)
{
    if(ic == 0)
    {
        P1OUT = 0;
        ic++;
    }
    else if(ic == 1)
    {
        P1OUT |= LSB;
        ic++;
    }
    else if(ic == 2)
    {
        P1OUT &= ~LSB;
        P1OUT |= MSB;
        ic++;
    }
    else if(ic == 3)
    {
        P1OUT |= LSB;
        ic = 0;
    }
    P1IFG &= ~BUTTON;
}
