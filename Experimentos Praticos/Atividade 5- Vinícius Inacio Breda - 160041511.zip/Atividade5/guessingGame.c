#include <msp430g2553.h>

#define BUTTON BIT3 // define do bot�o
#define WRNG   BIT6 // define do led vermelho
#define RGT   BIT0 // define do led verde

int bic = 0; // button interrupt counter
int tic = 0; // timer interrupt counter
int endGame = 0;
int valor = 1;

int rand(int numero)
{
    int num = numero;
    num = (num * 17) % 7;
    return num;
}
// 1 -> 3
// 2 -> 6
// 3 -> 2
// 4 -> 5
// 5 -> 1
// 6 -> 4

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer
    P1DIR |= WRNG + RGT; // WRNG e RGT s�o sa�das
    P1OUT &= ~WRNG;
    P1OUT &= ~RGT;
    P1IE |= BUTTON; // P1.3 interrupt enabled
    P1IES |= BUTTON;  //low to high transition
    P1IFG &= ~BUTTON; // P1.3 IFG cleared
    CCR0 = 25000 - 1;
    TACCTL0 = CCIE;
    TACTL = MC_1 | ID_3 | TASSEL_2 | TACLR;
    __bis_SR_register(GIE | LPM0_bits);
}

#pragma vector = PORT1_VECTOR
__interrupt void BUTTON_ISR(void)
{
    bic++;
    CCR0 = 25000 - 1;
    TACTL |= TACLR;
    P1IFG &= ~BUTTON;
}

#pragma vector = TIMER0_A0_VECTOR
__interrupt void TIMER_ISR(void)
{
    if((tic == 50) && (bic == valor))
    {
        tic = 0;
        P1OUT |= RGT;
        endGame = 1;
    }
    else if ((tic == 50) && (bic != valor))
    {
        P1OUT |= WRNG;
        tic = 0;
        endGame = 1;
    } else if ((endGame == 1) && (tic == 25))
    {
        P1OUT = 0;
        bic = 0;
        valor = rand(valor);
        endGame = 0;
        CCR0 = 25000 - 1;
        TACTL |= TACLR;
    }
    tic++;
}
