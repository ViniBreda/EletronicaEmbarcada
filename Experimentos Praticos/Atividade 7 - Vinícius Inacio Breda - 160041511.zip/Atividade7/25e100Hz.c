#include <msp430g2553.h>

#define     LED    BIT6

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer
    P1DIR |= LED;              // seta todos os outros pinos como input menos o do LED, que � setado como output
    P1SEL |= LED;
    CCR0 = 1249;
    CCTL1= OUTMOD_7;
    CCR1 = 312;
    TACTL = MC_1 | ID_3 | TASSEL_2;
}
