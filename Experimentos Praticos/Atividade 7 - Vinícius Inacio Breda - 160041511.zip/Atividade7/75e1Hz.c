#include <msp430g2553.h>

#define     LED    BIT6

int main(void)
{
    DCOCTL = DCO0 + DCO1;
    BCSCTL = RSEL1;

    WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer
    P1DIR |= LED;              // seta todos os outros pinos como input menos o do LED, que � setado como output
    P1SEL |= LED;
    CCR0 = 18750;
    CCTL1= OUTMOD_7;
    CCR1 = 14063;
    TACTL = MC_1 | ID_3 | TASSEL_2;
}
